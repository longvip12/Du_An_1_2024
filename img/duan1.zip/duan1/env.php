<?php
//lấy thư mục gốc của file
const ROOT_DIR = __DIR__ . "/";
//láy đường dẫn website
const ROOT_URL = "http://localhost/duan1/";
//lưu đường dẫn admin 
const ADMIN_URL = ROOT_URL . "admin/";