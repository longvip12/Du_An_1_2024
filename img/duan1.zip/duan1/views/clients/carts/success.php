<?php include_once ROOT_DIR . "views/clients/header.php" ?>

<div class="container mt-5">
    <h2>Đặt hàng thành công</h2>
    <p>Quay lại trang chủ <a href="<?= ROOT_URL?>">Trang chủ</a></p>
</div>

<?php include_once ROOT_DIR . "views/clients/footer.php" ?>